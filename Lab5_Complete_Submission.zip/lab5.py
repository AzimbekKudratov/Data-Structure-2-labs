"""Week 5 Lab - Hashing and Hash Tables: STARTER CODE.
 
Complete every function marked TODO. Run this file to test your work:
    python lab5_starter.py
Each test prints PASS, FAIL or TODO. Do not change the test functions.
"""
import random
 
MASK64 = (1 << 64) - 1
GOLDEN64 = 0x9E3779B97F4A7C15          # 2^64 / golden ratio, odd
SECOND64 = 0xC2B2AE3D27D4EB4F          # another large odd constant
P61 = (1 << 61) - 1                    # Mersenne prime for universal hashing
 
 
# ------------------------------------------------------------------ hash functions
def h_division(k, m):
    """TODO A1: return k mod m."""
    return k % m
 
 
def h_multiplication(k, bits):
    """TODO A1: multiply k by GOLDEN64, keep 64 bits (& MASK64), return the top `bits`
    bits."""
    return ((k * GOLDEN64) & MASK64) >> (64 - bits)
 
 
def poly_hash(s, base=31, mod=(1 << 61) - 1):
    """TODO A1: Horner's rule: h = (h * base + ord(ch)) % mod for every character."""
    
    h = 0
    for ch in s:
        h = (h * base + ord(ch)) % mod
    return h
 
 
def sum_hash(s):
    """A deliberately BAD string hash: anagrams always collide."""
    return sum(ord(ch) for ch in s)
 
 
def fnv1a_32(data: bytes):
    """TODO A1: start at 0x811C9DC5; for each byte: h ^= b, then h = (h * 0x01000193) &
    0xFFFFFFFF."""
    
    h = 0x811C9DC5
    for b in data:
        h = ((h ^ b) * 0x01000193) & 0xFFFFFFFF
    return h
 
 
class UniversalHash:
    """h(k) = ((a k + b) mod p) mod m with random a, b: a universal family."""
 
    def __init__(self, m, rng=None):
        rng = rng or random.Random()
        self.m, self.a, self.b = m, rng.randrange(1, P61), rng.randrange(0, P61)
 
    def __call__(self, k):
        return ((self.a * k + self.b) % P61) % self.m
 
 
def key_int(key):
    """Turn any hashable key into a non-negative integer (Python's hash for non-ints)."""
    return key if isinstance(key, int) and key >= 0 else hash(key) & MASK64
 
 
# ------------------------------------------------------------------ separate chaining
class ChainedHashTable:
    def __init__(self, capacity=8, max_load=1.0, resize=True, index_fn=None):
        self.m = capacity
        self.buckets = [[] for _ in range(capacity)]
        self.n = 0
        self.max_load = max_load
        self.resize_enabled = resize
        self.index_fn = index_fn            # custom (key, m) -> bucket, for experiments
        self.probes = 0                     # key comparisons
        self.moves = 0                      # entries moved by resizing
        self.resizes = 0
 
    def _index(self, key):
        if self.index_fn:
            return self.index_fn(key, self.m)
        # multiplicative hash, then keep the HIGH bits scaled to [0, m) (works for any m)
        return (((key_int(key) * GOLDEN64) & MASK64) * self.m) >> 64
 
    def __len__(self):
        return self.n
 
    def load_factor(self):
        return self.n / self.m
 
    def get(self, key, default=None):
        """TODO B1: scan the bucket of key; add 1 to self.probes per key compared;
        return value or default."""
        
        for k, v in self.buckets[self._index(key)]:
            self.probes += 1
            if k == key: return v
        return default
 
    def __contains__(self, key):
        sentinel = object()
        return self.get(key, sentinel) is not sentinel
 
    def put(self, key, value):
        """TODO B1: update if present (count probes), else append [key, value], n += 1,
        and resize to 2m when n / m > max_load (if resize_enabled)."""
        
        bucket = self.buckets[self._index(key)]
        for pair in bucket:
            self.probes += 1
            if pair[0] == key:
                pair[1] = value
                return
        bucket.append([key, value])
        self.n += 1
        if self.resize_enabled and self.load_factor() > self.max_load:
            self._resize(self.m * 2)
 
    def delete(self, key):
        """TODO B1: remove key from its bucket (count probes); return True if it was
        present."""
        
        bucket = self.buckets[self._index(key)]
        for i, pair in enumerate(bucket):
            self.probes += 1
            if pair[0] == key:
                bucket.pop(i)
                self.n -= 1
                return True
        return False
 
    def _resize(self, new_m):
        """TODO B2: new bucket array of size new_m; re-insert every pair (count
        self.moves); self.resizes += 1."""
        
        old = list(self.items())
        self.m = new_m
        self.buckets = [[] for _ in range(new_m)]
        self.n = 0
        self.resizes += 1
        for k, v in old:
            self.buckets[self._index(k)].append([k, v])
            self.n += 1
            self.moves += 1
 
    def chain_lengths(self):
        return [len(b) for b in self.buckets]
 
    def items(self):
        for b in self.buckets:
            for k, v in b:
                yield k, v
 
 
# ------------------------------------------------------------------ open addressing
EMPTY = None
DELETED = object()                         # tombstone
 
 
class OpenHashTable:
    """Open addressing in a power-of-two table. probing: 'linear', 'quadratic', 'double'."""
 
    def __init__(self, capacity=8, probing="linear", max_load=0.5, resize=True):
        bits = max(3, (capacity - 1).bit_length())
        self.bits, self.m = bits, 1 << bits
        self.keys = [EMPTY] * self.m
        self.vals = [None] * self.m
        self.n = 0                         # live keys
        self.tombs = 0                     # DELETED markers
        self.probing = probing
        self.max_load = max_load
        self.resize_enabled = resize
        self.probes = 0
        self.moves = 0
        self.resizes = 0
 
    def __len__(self):
        return self.n
 
    def load_factor(self):
        return self.n / self.m
 
    def _h1(self, key):
        return ((key_int(key) * GOLDEN64) & MASK64) >> (64 - self.bits)
 
    def _h2(self, key):                    # odd step: coprime with 2^bits, visits every slot
        return (((key_int(key) * SECOND64) & MASK64) >> (64 - self.bits)) | 1
 
    def _probe_seq(self, key):
        """TODO C1: yield m slot indices. linear: h + i; quadratic: h + i(i+1)/2;
        double: h + i * self._h2(key). All & (m - 1)."""
        
        h = self._h1(key)
        step = self._h2(key) if self.probing == "double" else 1
        for i in range(self.m):
            off = i if self.probing == "linear" else (i * (i + 1) // 2 if self.probing == "quadratic" else i * step)
            yield (h + off) & (self.m - 1)
 
    def _find(self, key):
        """TODO C2: walk the probe sequence counting probes. Return (slot of key or
        None, first reusable slot: first DELETED seen, else the EMPTY slot that
        ended the search)."""
        
        first_deleted = None
        for j in self._probe_seq(key):
            self.probes += 1
            k = self.keys[j]
            if k is EMPTY: return None, (first_deleted if first_deleted is not None else j)
            if k is DELETED:
                if first_deleted is None: first_deleted = j
            elif k == key: return j, j
        return None, first_deleted
 
    def get(self, key, default=None):
        j, _ = self._find(key)
        return default if j is None else self.vals[j]
 
    def __contains__(self, key):
        return self._find(key)[0] is not None
 
    def put(self, key, value):
        """TODO C2: if (n + tombs + 1) / m > max_load and resize_enabled, call _rehash
        (double m if live keys alone exceed max_load / 2, else same m). Then update
        or insert using _find; reusing a DELETED slot decrements tombs."""
        
        j, slot = self._find(key)
        if j is not None:
            self.vals[j] = value
            return
        if self.resize_enabled and (self.n + self.tombs + 1) / self.m > self.max_load:
            self._rehash(self.m * 2 if (self.n + 1) / self.m > self.max_load / 2 else self.m)
            j, slot = self._find(key)
        if slot is None: raise OverflowError("Hash table is full")
        if self.keys[slot] is DELETED: self.tombs -= 1
        self.keys[slot], self.vals[slot] = key, value
        self.n += 1
 
    def delete(self, key):
        """TODO C2: find the key; replace it by DELETED (a tombstone); n -= 1, tombs +=
        1; return True/False."""
        
        j, _ = self._find(key)
        if j is None: return False
        self.keys[j], self.vals[j] = DELETED, None
        self.n -= 1
        self.tombs += 1
        return True
 
    def _rehash(self, new_m):
        """TODO E3: rebuild with size new_m (power of two): re-insert live keys only
        (count moves), so all tombstones disappear."""
        
        old = list(self.items())
        self.bits = max(3, (new_m - 1).bit_length())
        self.m = 1 << self.bits
        self.keys, self.vals = [EMPTY] * self.m, [None] * self.m
        self.n = self.tombs = 0
        self.resizes += 1
        for k, v in old:
            for j in self._probe_seq(k):
                if self.keys[j] is EMPTY:
                    self.keys[j], self.vals[j] = k, v
                    self.n += 1
                    self.moves += 1
                    break
 
    def clusters(self):
        """Lengths of maximal runs of occupied slots (wrapping around)."""
        occ = [k is not EMPTY for k in self.keys]
        if all(occ):
            return [self.m]
        start = occ.index(False)
        runs, cur = [], 0
        for i in range(1, self.m + 1):
            if occ[(start + i) % self.m]:
                cur += 1
            elif cur:
                runs.append(cur)
                cur = 0
        return runs
 
    def items(self):
        for k, v in zip(self.keys, self.vals):
            if k is not EMPTY and k is not DELETED:
                yield k, v
 
 
# ======================================================== tests (do not edit)
def run(name, fn):
    try:
        fn()
        print(f"PASS  {name}")
    except NotImplementedError:
        print(f"TODO  {name}")
    except AssertionError as e:
        print(f"FAIL  {name}  {e}")
 
 
def test_hash_functions():
    assert h_division(1234, 100) == 34, "division method"
    assert 0 <= h_multiplication(123456789, 10) < 1024, "multiplication range"
    spread = h_multiplication(100, 10) != h_multiplication(200, 10)
    assert spread, "multiplication spreads keys"
    assert poly_hash("ab") == 97 * 31 + 98, "polynomial hash with base 31"
    assert poly_hash("listen") != poly_hash("silent"), "polynomial hash must use order"
    assert fnv1a_32(b"") == 0x811C9DC5 and fnv1a_32(b"a") == 0xE40C292C, "FNV-1a test vectors"
 
 
def check_against_dict(make, ops=4000, seed=1):
    rng = random.Random(seed)
    t, ref = make(), {}
    for _ in range(ops):
        k = rng.choice([rng.randrange(300), f"k{rng.randrange(300)}"])
        r = rng.random()
        if r < 0.5:
            v = rng.random()
            t.put(k, v)
            ref[k] = v
        elif r < 0.75:
            assert t.delete(k) == (k in ref), f"delete({k!r}) wrong"
            ref.pop(k, None)
        else:
            assert t.get(k) == ref.get(k), f"get({k!r}) wrong"
    assert len(t) == len(ref), "size wrong"
    assert dict(t.items()) == ref, "contents differ from dict"
 
 
def test_chaining():
    check_against_dict(lambda: ChainedHashTable())
    t = ChainedHashTable(4, max_load=1.0)
    for k in range(100):
        t.put(k, k)
    assert t.load_factor() <= 1.0 and t.m >= 100, "table must double when alpha > max_load"
 
 
def test_probe_sequences():
    for p in ("linear", "quadratic", "double"):
        t = OpenHashTable(capacity=64, probing=p, resize=False)
        seq = list(t._probe_seq(424242))
        covers = sorted(seq) == list(range(64))
        assert covers, f"{p} probing must visit every slot exactly once"
 
 
def test_open_addressing():
    for p in ("linear", "quadratic", "double"):
        check_against_dict(lambda p=p: OpenHashTable(probing=p), seed=7)
 
 
def test_tombstones():
    t = OpenHashTable(capacity=16, probing="linear", resize=False)
    t.keys = [None] * 16
    # force a cluster: keys with the same home slot
    home = t._h1(0)
    same = [k for k in range(1, 5000) if t._h1(k) == home][:3]
    for k in same:
        t.put(k, k)
    t.delete(same[1])
    assert t.get(same[2]) == same[2], "key after a deleted slot must still be found"
    assert t.tombs == 1, "delete must leave exactly one tombstone"
 
 
if __name__ == "__main__":
    run("Part A  hash functions", test_hash_functions)
    run("Part B  chaining vs dict + resizing", test_chaining)
    run("Part C  probe sequences cover the table", test_probe_sequences)
    run("Part C  open addressing vs dict (3 schemes)", test_open_addressing)
    run("Part C  tombstones keep keys reachable", test_tombstones)
