"""Graph Algorithms Lab - BFS, DFS, Dijkstra
Student: Azimbek Kudratov
Student ID: [enter your ID]
"""

GRAPH1 = {
    'A': ['B', 'C'], 'B': ['A', 'D', 'E'], 'C': ['A', 'F'],
    'D': ['B'], 'E': ['B', 'F'], 'F': ['C', 'E', 'G'], 'G': ['F']
}
GRAPH2 = {
    'A': {'B': 4, 'C': 2},
    'B': {'A': 4, 'C': 1, 'D': 5},
    'C': {'A': 2, 'B': 1, 'D': 8, 'E': 10},
    'D': {'B': 5, 'C': 8, 'E': 2, 'F': 6},
    'E': {'C': 10, 'D': 2, 'F': 3},
    'F': {'D': 6, 'E': 3}
}


def bfs(graph, start):
    """FIFO queue implemented with a list and a moving front index."""
    queue = [start]
    front = 0
    distance = {start: 0}
    parent = {start: None}
    order = []
    while front < len(queue):
        u = queue[front]
        front += 1
        order.append(u)
        for v in sorted(graph[u]):
            if v not in distance:  # mark at enqueue, not dequeue
                distance[v] = distance[u] + 1
                parent[v] = u
                queue.append(v)
    return order, distance, parent


def path_to(parent, target):
    """Follow parents backward and reverse to reconstruct a path."""
    if target not in parent:
        return None
    result = []
    while target is not None:
        result.append(target)
        target = parent[target]
    return list(reversed(result))


def dfs(graph, start):
    """LIFO stack implemented using list append/pop; no recursion."""
    stack = [start]
    visited = set()
    order = []
    while stack:
        u = stack.pop()
        if u in visited:
            continue
        visited.add(u)  # mark at pop; duplicates may be skipped
        order.append(u)
        for v in sorted(graph[u], reverse=True):
            if v not in visited:
                stack.append(v)
    return order


def dijkstra(graph, source):
    """Settle the smallest tentative distance and relax outgoing edges."""
    nodes = sorted(graph)
    dist = {v: float('inf') for v in nodes}
    prev = {v: None for v in nodes}
    settled = set()
    dist[source] = 0
    def state():
        return ' '.join(f"{v}={'INF' if dist[v] == float('inf') else dist[v]}" for v in nodes)
    print(f"init          | {state()}")
    while True:
        candidates = [v for v in nodes if v not in settled and dist[v] != float('inf')]
        if not candidates:
            break
        u = min(candidates, key=lambda v: (dist[v], v))
        settled.add(u)
        for v in sorted(graph[u]):
            if v not in settled:
                candidate = dist[u] + graph[u][v]
                if candidate < dist[v]:  # relaxation
                    dist[v] = candidate
                    prev[v] = u
        print(f"settle {u} ({dist[u]})".ljust(14) + f"| {state()}")
    return dist, prev


def main():
    order, distance, parent = bfs(GRAPH1, 'A')
    print('BFS order from A: ' + ' '.join(order))
    for start, target in [('A', 'G'), ('D', 'G')]:
        _, dist, parents = bfs(GRAPH1, start)
        path = path_to(parents, target)
        if path is None:
            print(f'Shortest {start} -> {target}: no path')
        else:
            print(f"Shortest {start} -> {target}: distance {dist[target]}, path {' -> '.join(path)}")
    print('DFS order from A: ' + ' '.join(dfs(GRAPH1, 'A')))
    print('DFS order from G: ' + ' '.join(dfs(GRAPH1, 'G')))
    dist, prev = dijkstra(GRAPH2, 'A')
    for target in sorted(GRAPH2):
        if target == 'A':
            continue
        path = path_to(prev, target)
        if path is None:
            print(f'A to {target}: no path')
        else:
            print(f"A to {target}: cost {dist[target]}: {' -> '.join(path)}")


if __name__ == '__main__':
    main()
