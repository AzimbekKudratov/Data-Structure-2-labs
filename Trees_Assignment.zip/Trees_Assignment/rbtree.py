
class RBNode:
    def __init__(self, key, color="RED"):
        self.key = key
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RBTree:
    RED = "RED"
    BLACK = "BLACK"

    def __init__(self):
        self.NIL = RBNode(None, self.BLACK)
        self.root = self.NIL

    def search(self, key):
        current = self.root

        while current != self.NIL:
            if key == current.key:
                return current
            elif key < current.key:
                current = current.left
            else:
                current = current.right

        return None

    def left_rotate(self, x):
        y = x.right
        x.right = y.left

        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent

        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right

        if x.right != self.NIL:
            x.right.parent = y

        x.parent = y.parent

        if y.parent == self.NIL:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, key):
        node = RBNode(key)
        node.left = self.NIL
        node.right = self.NIL

        parent = self.NIL
        current = self.root

        while current != self.NIL:
            parent = current

            if key == current.key:
                return
            elif key < current.key:
                current = current.left
            else:
                current = current.right

        node.parent = parent

        if parent == self.NIL:
            self.root = node
        elif key < parent.key:
            parent.left = node
        else:
            parent.right = node

        self._fix_insert(node)

    def _fix_insert(self, node):
        while node.parent.color == self.RED:
            if node.parent == node.parent.parent.left:
                uncle = node.parent.parent.right

                if uncle.color == self.RED:
                    node.parent.color = self.BLACK
                    uncle.color = self.BLACK
                    node.parent.parent.color = self.RED
                    node = node.parent.parent
                else:
                    if node == node.parent.right:
                        node = node.parent
                        self.left_rotate(node)

                    node.parent.color = self.BLACK
                    node.parent.parent.color = self.RED
                    self.right_rotate(node.parent.parent)

            else:
                uncle = node.parent.parent.left

                if uncle.color == self.RED:
                    node.parent.color = self.BLACK
                    uncle.color = self.BLACK
                    node.parent.parent.color = self.RED
                    node = node.parent.parent
                else:
                    if node == node.parent.left:
                        node = node.parent
                        self.right_rotate(node)

                    node.parent.color = self.BLACK
                    node.parent.parent.color = self.RED
                    self.left_rotate(node.parent.parent)

        self.root.color = self.BLACK

    def height(self):
        def get_height(node):
            if node == self.NIL:
                return -1

            return 1 + max(
                get_height(node.left),
                get_height(node.right)
            )

        return get_height(self.root)

    def inorder(self):
        result = []

        def walk(node):
            if node == self.NIL:
                return

            walk(node.left)
            result.append(node.key)
            walk(node.right)

        walk(self.root)
        return result

    def is_valid(self):
        if self.root == self.NIL:
            return True

        if self.root.color != self.BLACK:
            return False

        def check(node, low, high):
            if node == self.NIL:
                return 1

            if low is not None and node.key <= low:
                return -1

            if high is not None and node.key >= high:
                return -1

            if node.color not in (self.RED, self.BLACK):
                return -1

            if node.color == self.RED:
                if (node.left.color == self.RED or
                        node.right.color == self.RED):
                    return -1

            left_height = check(node.left, low, node.key)
            right_height = check(node.right, node.key, high)

            if left_height == -1 or right_height == -1:
                return -1

            if left_height != right_height:
                return -1

            return left_height + (1 if node.color == self.BLACK else 0)

        return check(self.root, None, None) != -1