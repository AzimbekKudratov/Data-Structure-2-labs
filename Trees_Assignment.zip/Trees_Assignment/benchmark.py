
import random
import time
import bisect
import csv
import math
import matplotlib.pyplot as plt

from week3_lab import BST, AVLNode, avl_insert, avl_search, avl_height
from rbtree import RBTree

class AVLTree:
    def __init__(self):
        self.root = None

    def insert(self, key):
        self.root = avl_insert(self.root, key)

    def search(self, key):
        return avl_search(self.root, key)

    def height(self):
        return avl_height(self.root)


class SortedList:
    def __init__(self):
        self.items = []

    def insert(self, key):
        bisect.insort(self.items, key)

    def search(self, key):
        index = bisect.bisect_left(self.items, key)
        return index < len(self.items) and self.items[index] == key

    def height(self):
        return None

class RedBlackTree:
    def __init__(self):
        self.tree = RBTree()

    def insert(self, key):
        self.tree.insert(key)

    def search(self, key):
        return self.tree.search(key) is not None

    def height(self):
        return self.tree.height()


def run_benchmark(tree_class, keys, search_keys):
    tree = tree_class()

    start = time.perf_counter()
    for key in keys:
        tree.insert(key)
    insert_time = time.perf_counter() - start

    start = time.perf_counter()
    for key in search_keys:
        tree.search(key)
    search_time = time.perf_counter() - start

    return insert_time, search_time, tree.height()


def main():
    sizes = [1000, 2000, 4000, 8000]
    structures = [
        ("BST", BST),
        ("AVL", AVLTree),
        ("Red-Black", RedBlackTree),
        ("Sorted List", SortedList),
    ]

    results = []

    for order in ["random", "sorted"]:
        for n in sizes:
            print(f"\nTesting {order} input, n={n}...")
            numbers = list(range(n))

            if order == "random":
                random.shuffle(numbers)

            search_keys = random.sample(range(n), 1000)

            for name, tree_class in structures:
                # Run twice and keep the second measurement.
                run_benchmark(tree_class, numbers, search_keys)
                insert_time, search_time, height = run_benchmark(
                    tree_class, numbers, search_keys
                )

                results.append({
                    "order": order,
                    "n": n,
                    "structure": name,
                    "insert_seconds": insert_time,
                    "search_seconds": search_time,
                    "height": height,
                })

                print(
                    f"{name}: insert={insert_time:.6f}s, "
                    f"search={search_time:.6f}s, height={height}"
                )

    with open("benchmark_results.csv", "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

    # Plot 1: heights for random input
    plt.figure()
    for name, _ in structures:
        rows = [
            r for r in results
            if r["order"] == "random" and r["structure"] == name
            and r["height"] is not None
        ]
        plt.plot(
            [r["n"] for r in rows],
            [r["height"] for r in rows],
            marker="o",
            label=name,
        )

    plt.plot(
        sizes,
        [math.log2(n) for n in sizes],
        linestyle="--",
        label="log2(n)",
    )
    plt.xlabel("Number of keys (n)")
    plt.ylabel("Tree height (edges)")
    plt.title("Tree Heights — Random Input")
    plt.legend()
    plt.tight_layout()
    plt.savefig("random_heights.png")
    plt.close()

    # Plot 2: heights for sorted input
    plt.figure()
    for name, _ in structures:
        if name == "Sorted List":
            continue

        rows = [
            r for r in results
            if r["order"] == "sorted" and r["structure"] == name
        ]
        plt.plot(
            [r["n"] for r in rows],
            [r["height"] for r in rows],
            marker="o",
            label=name,
        )

    plt.yscale("log")
    plt.xlabel("Number of keys (n)")
    plt.ylabel("Tree height (edges, log scale)")
    plt.title("Tree Heights — Sorted Input")
    plt.legend()
    plt.tight_layout()
    plt.savefig("sorted_heights.png")
    plt.close()

    print("\nBenchmark complete!")
    print("Saved: benchmark_results.csv")
    print("Saved: random_heights.png")
    print("Saved: sorted_heights.png")


if __name__ == "__main__":
    main()
