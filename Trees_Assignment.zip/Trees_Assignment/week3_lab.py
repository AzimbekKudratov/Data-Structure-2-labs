
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, key):
        new_node = Node(key)

        if self.root is None:
            self.root = new_node
            return

        current = self.root

        while True:
            if key == current.key:
                return  # Ignore duplicates

            if key < current.key:
                if current.left is None:
                    current.left = new_node
                    return
                current = current.left
            else:
                if current.right is None:
                    current.right = new_node
                    return
                current = current.right

    def search(self, key):
        current = self.root

        while current is not None:
            if key == current.key:
                return True
            elif key < current.key:
                current = current.left
            else:
                current = current.right

        return False

    def height(self):
        if self.root is None:
            return -1

        stack = [(self.root, 0)]
        max_depth = 0

        while stack:
            node, depth = stack.pop()
            max_depth = max(max_depth, depth)

            if node.left is not None:
                stack.append((node.left, depth + 1))

            if node.right is not None:
                stack.append((node.right, depth + 1))

        return max_depth


if __name__ == "__main__":
    tree = BST()

    for key in [5, 3, 7, 2, 4, 6, 8]:
        tree.insert(key)

    print("BST insertion: PASS")
    print("Search existing key:", tree.search(4))
    print("Search missing key:", tree.search(10))
    print("Tree height:", tree.height())

    # Test an empty tree
    empty_tree = BST()
    assert empty_tree.height() == -1

    # Test duplicates
    tree.insert(5)
    assert tree.height() == 2

    # Test a chain of 8,000 nodes without recursion
    chain = BST()
    for key in range(8000):
        chain.insert(key)

    assert chain.height() == 7999
    assert chain.search(7999)
    assert not chain.search(8000)

    print("Empty tree: PASS")
    print("Duplicate handling: PASS")
    print("8,000-node chain: PASS")





def rotate_left(x):
    if x is None or x.right is None:
        return x

    y = x.right
    x.right = y.left
    y.left = x

    return y


def rotate_right(y):
    if y is None or y.left is None:
        return y

    x = y.left
    y.left = x.right
    x.right = y

    return x


def inorder(node):
    result = []
    stack = []
    current = node

    while stack or current is not None:
        while current is not None:
            stack.append(current)
            current = current.left

        current = stack.pop()
        result.append(current.key)
        current = current.right

    return result


# Rotation tests
rotation_tree = BST()
for key in [10, 5, 15, 12, 20]:
    rotation_tree.insert(key)

before = inorder(rotation_tree.root)
rotation_tree.root = rotate_left(rotation_tree.root)
after_left = inorder(rotation_tree.root)

assert before == after_left
assert rotation_tree.root.key == 15

rotation_tree.root = rotate_right(rotation_tree.root)
after_right = inorder(rotation_tree.root)

assert before == after_right
assert rotation_tree.root.key == 10

print("Left rotation: PASS")
print("Right rotation: PASS")
print("In-order preservation: PASS")





class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 0


def avl_height(node):
    return node.height if node is not None else -1


def update_height(node):
    node.height = 1 + max(
        avl_height(node.left),
        avl_height(node.right)
    )


def balance_factor(node):
    return avl_height(node.left) - avl_height(node.right)


def avl_rotate_right(y):
    x = y.left
    middle = x.right

    x.right = y
    y.left = middle

    update_height(y)
    update_height(x)

    return x


def avl_rotate_left(x):
    y = x.right
    middle = y.left

    y.left = x
    x.right = middle

    update_height(x)
    update_height(y)

    return y


def avl_insert(node, key):
    if node is None:
        return AVLNode(key)

    if key < node.key:
        node.left = avl_insert(node.left, key)
    elif key > node.key:
        node.right = avl_insert(node.right, key)
    else:
        return node

    update_height(node)
    balance = balance_factor(node)

    # Left-left case
    if balance > 1 and key < node.left.key:
        return avl_rotate_right(node)

    # Right-right case
    if balance < -1 and key > node.right.key:
        return avl_rotate_left(node)

    # Left-right case
    if balance > 1 and key > node.left.key:
        node.left = avl_rotate_left(node.left)
        return avl_rotate_right(node)

    # Right-left case
    if balance < -1 and key < node.right.key:
        node.right = avl_rotate_right(node.right)
        return avl_rotate_left(node)

    return node


def avl_search(node, key):
    while node is not None:
        if key == node.key:
            return True
        node = node.left if key < node.key else node.right
    return False


def avl_is_valid(root):
    def check(node, low, high):
        if node is None:
            return -1

        assert low is None or node.key > low, "BST order violation"
        assert high is None or node.key < high, "BST order violation"

        left_height = check(node.left, low, node.key)
        right_height = check(node.right, node.key, high)

        assert abs(left_height - right_height) <= 1, "AVL balance violation"
        assert node.height == 1 + max(left_height, right_height), "Height incorrect"

        return node.height

    check(root, None, None)
    return True


# AVL tests
avl_root = None
for value in [50, 40, 30, 45, 47, 20, 10]:
    avl_root = avl_insert(avl_root, value)

assert avl_is_valid(avl_root)
assert avl_search(avl_root, 47)
assert not avl_search(avl_root, 99)

# A sorted insertion sequence should remain balanced
sorted_avl = None
for value in range(1000):
    sorted_avl = avl_insert(sorted_avl, value)

assert avl_is_valid(sorted_avl)
assert sorted_avl.height < 20

print("AVL insertion and balancing: PASS")
print("AVL search: PASS")
print("AVL validator: PASS")
print("AVL sorted-input test: PASS")







def is_valid_rb(tree):
    """
    Tree format: (key, colour, left, right)
    Colours: 'B' for black, 'R' for red.
    None represents a black NIL leaf.

    Returns (True, black_height) or (False, reason).
    Black-height includes the NIL leaf.
    """

    if tree is None:
        return True, 1

    def check(node, low, high):
        if node is None:
            return 1

        key, colour, left, right = node
        colour = colour.upper()

        if colour not in ("R", "B"):
            raise ValueError(f"Invalid colour at node {key}")

        if low is not None and key <= low:
            raise ValueError(f"BST order violation at node {key}")

        if high is not None and key >= high:
            raise ValueError(f"BST order violation at node {key}")

        if colour == "R":
            if left is not None and left[1].upper() == "R":
                raise ValueError(f"Red node {key} has red left child")

            if right is not None and right[1].upper() == "R":
                raise ValueError(f"Red node {key} has red right child")

        left_black_height = check(left, low, key)
        right_black_height = check(right, key, high)

        if left_black_height != right_black_height:
            raise ValueError(f"Black-height mismatch at node {key}")

        return left_black_height + (1 if colour == "B" else 0)

    try:
        if tree[1].upper() != "B":
            return False, "Root must be black"

        height = check(tree, None, None)
        return True, height

    except (AssertionError, ValueError) as error:
        return False, str(error)


# Red-Black validator tests
valid_rb_tree = (
    10, "B",
    (5, "R", None, None),
    (15, "R", None, None)
)

invalid_rb_tree = (
    10, "R",
    (5, "B", None, None),
    (15, "B", None, None)
)

assert is_valid_rb(valid_rb_tree) == (True, 2)
assert is_valid_rb(invalid_rb_tree)[0] is False
assert is_valid_rb(None) == (True, 1)

print("Red-Black valid tree test: PASS")
print("Red-Black invalid root test: PASS")
print("Red-Black empty tree test: PASS")
