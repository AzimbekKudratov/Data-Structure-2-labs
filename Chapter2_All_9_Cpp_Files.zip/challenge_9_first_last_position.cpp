#include <iostream>
#include <vector>
using namespace std;

// Time: O(log n), Space: O(1)
int findFirstPosition(const vector<int>& numbers, int target) {
    int left = 0;
    int right = static_cast<int>(numbers.size()) - 1;
    int answer = -1;

    while (left <= right) {
        int middle = left + (right - left) / 2;
        if (numbers[middle] == target) {
            answer = middle;
            right = middle - 1;
        } else if (numbers[middle] < target) {
            left = middle + 1;
        } else {
            right = middle - 1;
        }
    }
    return answer;
}

int findLastPosition(const vector<int>& numbers, int target) {
    int left = 0;
    int right = static_cast<int>(numbers.size()) - 1;
    int answer = -1;

    while (left <= right) {
        int middle = left + (right - left) / 2;
        if (numbers[middle] == target) {
            answer = middle;
            left = middle + 1;
        } else if (numbers[middle] < target) {
            left = middle + 1;
        } else {
            right = middle - 1;
        }
    }
    return answer;
}

vector<int> searchRange(const vector<int>& numbers, int target) {
    return {findFirstPosition(numbers, target), findLastPosition(numbers, target)};
}

void test(const vector<int>& numbers, int target) {
    vector<int> answer = searchRange(numbers, target);
    cout << "(" << answer[0] << ", " << answer[1] << ")" << endl;
}

int main() {
    test({5, 7, 7, 8, 8, 8, 10}, 8);
    test({5, 7, 7, 8, 8, 10}, 6);
    test({1, 2, 3, 4, 5}, 3);
    test({}, 3);
    return 0;
}
