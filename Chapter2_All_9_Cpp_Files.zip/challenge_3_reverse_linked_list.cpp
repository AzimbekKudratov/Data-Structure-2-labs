#include <iostream>
using namespace std;

// Time: O(n), Space: O(1)
struct Node {
    int value;
    Node* next;
};

Node* reverseList(Node* head) {
    Node* previousNode = nullptr;
    Node* currentNode = head;
    while (currentNode != nullptr) {
        Node* nextNode = currentNode->next;
        currentNode->next = previousNode;
        previousNode = currentNode;
        currentNode = nextNode;
    }
    return previousNode;
}

void printList(Node* head) {
    while (head != nullptr) {
        cout << head->value << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* n1 = new Node{1, nullptr};
    Node* n2 = new Node{2, nullptr};
    Node* n3 = new Node{3, nullptr};
    n1->next = n2; n2->next = n3;
    printList(reverseList(n1));

    Node* single = new Node{10, nullptr};
    printList(reverseList(single));

    printList(reverseList(nullptr));
    return 0;
}
