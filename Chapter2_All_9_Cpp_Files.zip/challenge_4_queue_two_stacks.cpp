#include <iostream>
#include <stack>
#include <stdexcept>
using namespace std;

// Time: enqueue O(1), dequeue amortized O(1), Space: O(n)
class QueueFromStacks {
private:
    stack<int> inputStack;
    stack<int> outputStack;
public:
    void enqueue(int value) { inputStack.push(value); }

    int dequeue() {
        if (outputStack.empty()) {
            while (!inputStack.empty()) {
                outputStack.push(inputStack.top());
                inputStack.pop();
            }
        }
        if (outputStack.empty()) throw runtime_error("Queue is empty!");
        int value = outputStack.top();
        outputStack.pop();
        return value;
    }
};

int main() {
    QueueFromStacks q;
    q.enqueue(1); q.enqueue(2); q.enqueue(3);
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    q.enqueue(4);
    cout << q.dequeue() << endl;
    cout << q.dequeue() << endl;
    try { q.dequeue(); }
    catch (const runtime_error& e) { cout << e.what() << endl; }
    return 0;
}
