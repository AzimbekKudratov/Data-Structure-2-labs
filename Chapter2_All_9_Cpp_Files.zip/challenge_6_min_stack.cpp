#include <iostream>
#include <stack>
#include <stdexcept>
#include <algorithm>
using namespace std;

// Time: O(1) for push, pop, top, getMin; Space: O(n)
class MinStack {
private:
    stack<int> values;
    stack<int> minimumValues;
public:
    void push(int value) {
        values.push(value);
        if (minimumValues.empty()) minimumValues.push(value);
        else minimumValues.push(min(value, minimumValues.top()));
    }

    void pop() {
        if (values.empty()) throw runtime_error("Stack is empty!");
        values.pop();
        minimumValues.pop();
    }

    int top() const {
        if (values.empty()) throw runtime_error("Stack is empty!");
        return values.top();
    }

    int getMin() const {
        if (minimumValues.empty()) throw runtime_error("Stack is empty!");
        return minimumValues.top();
    }
};

int main() {
    MinStack s;
    s.push(3); s.push(5); s.push(2);
    cout << s.getMin() << endl;
    s.pop();
    cout << s.getMin() << endl;
    s.push(1); s.push(1); s.pop();
    cout << s.getMin() << endl;
    cout << s.top() << endl;
    return 0;
}
