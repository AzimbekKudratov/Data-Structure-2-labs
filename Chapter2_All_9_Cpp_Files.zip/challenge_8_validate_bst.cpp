#include <iostream>
#include <climits>
using namespace std;

// Assumption: duplicate values are not allowed.
// Time: O(n), Space: O(h)
struct Node {
    int value;
    Node* left;
    Node* right;
    Node(int number) : value(number), left(nullptr), right(nullptr) {}
};

bool checkTree(Node* node, long long minimumValue, long long maximumValue) {
    if (node == nullptr) return true;
    if (node->value <= minimumValue || node->value >= maximumValue) return false;

    return checkTree(node->left, minimumValue, node->value) &&
           checkTree(node->right, node->value, maximumValue);
}

bool isValidBST(Node* root) {
    return checkTree(root, LLONG_MIN, LLONG_MAX);
}

int main() {
    Node* valid = new Node(5);
    valid->left = new Node(1);
    valid->right = new Node(8);
    valid->right->left = new Node(6);
    valid->right->right = new Node(9);
    cout << isValidBST(valid) << endl;

    Node* invalid = new Node(5);
    invalid->left = new Node(1);
    invalid->right = new Node(8);
    invalid->right->left = new Node(4);
    invalid->right->right = new Node(9);
    cout << isValidBST(invalid) << endl;

    Node* single = new Node(10);
    cout << isValidBST(single) << endl;

    cout << isValidBST(nullptr) << endl;
    return 0;
}
