#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

// Time: O(n) average, Space: O(n)
vector<int> findTwoNumbers(const vector<int>& numbers, int target) {
    unordered_map<int, int> previousNumbers;
    for (int currentIndex = 0; currentIndex < static_cast<int>(numbers.size()); currentIndex++) {
        int currentNumber = numbers[currentIndex];
        int numberWeNeed = target - currentNumber;
        if (previousNumbers.count(numberWeNeed))
            return {previousNumbers[numberWeNeed], currentIndex};
        previousNumbers[currentNumber] = currentIndex;
    }
    return {};
}

void test(const vector<int>& numbers, int target) {
    vector<int> answer = findTwoNumbers(numbers, target);
    if (answer.size() == 2)
        cout << "Indexes: " << answer[0] << ", " << answer[1] << endl;
    else
        cout << "No pair found" << endl;
}

int main() {
    test({2, 7, 11, 15}, 9);
    test({3, 2, 4}, 6);
    test({-5, 10, 0, 5}, 0);
    return 0;
}
