#include <iostream>
#include <stdexcept>
using namespace std;

// Time: append O(1) amortized, get/set O(1); Space: O(n)
class DynamicArray {
private:
    int* data;
    int currentSize;
    int capacity;

    void grow() {
        int newCapacity = capacity * 2;
        int* newData = new int[newCapacity];
        for (int i = 0; i < currentSize; i++) newData[i] = data[i];
        delete[] data;
        data = newData;
        capacity = newCapacity;
    }

public:
    DynamicArray() : currentSize(0), capacity(2) {
        data = new int[capacity];
    }

    DynamicArray(const DynamicArray&) = delete;
    DynamicArray& operator=(const DynamicArray&) = delete;

    ~DynamicArray() { delete[] data; }

    void append(int value) {
        if (currentSize == capacity) grow();
        data[currentSize++] = value;
    }

    int get(int index) const {
        if (index < 0 || index >= currentSize) throw out_of_range("Index out of range");
        return data[index];
    }

    void set(int index, int value) {
        if (index < 0 || index >= currentSize) throw out_of_range("Index out of range");
        data[index] = value;
    }

    int size() const { return currentSize; }
    int getCapacity() const { return capacity; }
};

int main() {
    DynamicArray numbers;
    numbers.append(10);
    numbers.append(20);
    cout << numbers.get(0) << " " << numbers.get(1) << endl;
    cout << "Capacity: " << numbers.getCapacity() << endl;

    numbers.append(30);
    cout << "Capacity: " << numbers.getCapacity() << endl;

    numbers.set(1, 99);
    cout << numbers.get(1) << endl;

    try { numbers.get(100); }
    catch (const out_of_range& e) { cout << e.what() << endl; }
    return 0;
}
