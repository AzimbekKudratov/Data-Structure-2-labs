#include <iostream>
using namespace std;

// Time: O(n), Space: O(1)
struct Node {
    int value;
    Node* next;
    Node(int number) : value(number), next(nullptr) {}
};

bool hasCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    return false;
}

int main() {
    Node* a = new Node(1);
    Node* b = new Node(2);
    Node* c = new Node(3);
    a->next = b; b->next = c; c->next = b;
    cout << hasCycle(a) << endl;

    Node* x = new Node(10);
    Node* y = new Node(20);
    x->next = y;
    cout << hasCycle(x) << endl;

    Node* single = new Node(100);
    single->next = single;
    cout << hasCycle(single) << endl;

    cout << hasCycle(nullptr) << endl;
    return 0;
}
