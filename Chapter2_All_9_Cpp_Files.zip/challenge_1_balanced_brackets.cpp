#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Time: O(n), Space: O(n)
bool isBalanced(const string& text) {
    stack<char> brackets;
    for (char c : text) {
        if (c == '(' || c == '[' || c == '{') brackets.push(c);
        else if (c == ')' || c == ']' || c == '}') {
            if (brackets.empty()) return false;
            char opening = brackets.top();
            brackets.pop();
            if ((c == ')' && opening != '(') ||
                (c == ']' && opening != '[') ||
                (c == '}' && opening != '{')) return false;
        }
    }
    return brackets.empty();
}

int main() {
    cout << isBalanced("(a[b]{c})") << endl;
    cout << isBalanced("([)]") << endl;
    cout << isBalanced("") << endl;
    cout << isBalanced(")") << endl;
    return 0;
}
